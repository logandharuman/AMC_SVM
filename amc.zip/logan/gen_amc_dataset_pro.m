function [x, label, fs, snr] = gen_amc_dataset_pro()
    classes = ["AM","FM","CARRIER","DIGITAL","NOISE"];
    label = classes(randi(numel(classes)));
    
    fs = 200e3; % Keep FS constant for easier FPGA feature extraction logic
    N = 4096;
    t = (0:N-1)/fs;
    snr = randsample(8:20, 1); % Train on a wider range
    
    fc = 0.2*fs + (0.1*fs*rand); % Random carrier
    fm = 500 + 2000*rand;        % Random message frequency

    switch label
        case "AM"
            m = cos(2*pi*fm*t);
            x = (1 + 0.8*m) .* cos(2*pi*fc*t);
        % case "FM"
        %     m = cos(2*pi*fm*t);
        %     x = cos(2*pi*fc*t + (fs/fm)*cumsum(m)/fs); % Realistic Beta
        case "FM"
            % Define a stable Deviation (e.g., 10% of fs or a fixed 5000Hz)
            delta_f = 5000; 
            m = cos(2*pi*fm*t);
            % Standard FM Formula: cos(2*pi*fc*t + 2*pi * delta_f * integral(m))
            % The 2*pi*delta_f/fs scales the integral correctly for discrete time
            phase_modulation = (2 * pi * delta_f / fs) * cumsum(m);
            x = cos(2*pi*fc*t + phase_modulation);
        case "CARRIER"
            x = cos(2*pi*fc*t);
        case "DIGITAL"
        M = 4; sps = 20;
        % Generate more symbols than needed to account for filter ramp-up/down
        Ns = ceil(N/sps) + 20; 
        bits = randi([0 M-1], 1, Ns);
        sym = pskmod(bits, M);
        
        % Pulse shaping
        beta = 0.5; span = 6;
        h = rcosdesign(beta, span, sps);
        x_bb = filter(h, 1, repelem(sym, sps)); 
        
        % Calculate a safe start point to avoid filter transients
        start_idx = (span*sps)/2 + 1; 
        x_bb = x_bb(start_idx : start_idx + N - 1); 
        x = real(x_bb .* exp(1j*2*pi*fc*t));
        case "NOISE"
            x = randn(1,N);
    end

    % --- THE EXPERT ADDITIONS ---
    % 1. Energy Normalization (CRITICAL for SVM)
    if label ~= "NOISE"
        x = x / sqrt(mean(x.^2)); 
    end
    
    % 2. Add AWGN
    x = awgn(x, snr, 'measured');
    
    % 3. Fixed-Point Simulation (Matches FPGA behavior)
    % Convert to 12-bit (standard ADC resolution)
    x = round(x .* (2^11 - 1)) / (2^11 - 1);
end