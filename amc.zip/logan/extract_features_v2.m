function feat = extract_features_v2(x, fs)
    N = length(x);
    env = abs(x);
    % Instantaneous frequency
    dphi = angle(x(2:end) .* conj(x(1:end-1))); 
    dphi_ac = dphi - mean(dphi);

    % --- Core Features (Raw) ---
    f1 = var(dphi_ac);                                     % Frequency Variance
    f2 = max(abs(dphi_ac)) / (mean(abs(dphi_ac)) + eps);    % Peakiness
    f3 = sum(abs(diff(dphi_ac >= 0))) / (N-1);             % Freq Zero-Crossing
    f4 = var(env) / (mean(env.^2) + eps);                  % Mag Variance
    f5 = max(env.^2) / (mean(env.^2) + eps);               % PAPR

    feat = [f1, f2, f3, f4, f5];

end