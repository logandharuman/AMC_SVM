clc; clear; close all;

% Load your saved model
load('Linear_Best_Model.mat'); % Should contain: trained_model, mu, sigma

% Identify class names (e.g., AM, Carrier, Digital, FM, Noise)
classNames = trained_model.ClassNames;
numClasses = length(classNames);
numFeatures = length(mu);

% Initialize matrices
W_raw = zeros(numFeatures, numClasses);
B_raw = zeros(1, numClasses);

% Loop through each binary learner to get Weights (Beta) and Bias
for i = 1:numClasses
    % In One-vs-All, each learner distinguishes one class from the rest
    binaryLearner = trained_model.BinaryLearners{i};
    
    W_raw(:, i) = binaryLearner.Beta;
    B_raw(i) = binaryLearner.Bias;
end

fprintf('Raw Weights and Biases extracted successfully.\n');

% 1. Fold Normalization into Weights and Biases
W_folded = W_raw ./ sigma'; 
B_folded = B_raw - sum((W_raw .* mu) ./ sigma, 2)';

% 2. Calculate the Global Safe Scale for Weights
% Find the maximum absolute value among all weights to avoid truncation
max_w = max(abs(W_folded(:)));
% We target 32760 to stay just inside the 16-bit signed limit (32767)
W_scale_safe = 32760 / max_w;

% 3. Apply Scaling
W_fixed = round(W_folded * W_scale_safe);

% 4. Align Bias to the Product Magnitude
% Since: Score = (Feature * W_folded) + B_folded
% And Features are Q1.15 (scaled by 2^15)
% The Bias must be scaled by (W_scale_safe * 2^15) to be in the same "units"
B_scale_safe = W_scale_safe * (2^15);
B_fixed = round(B_folded * B_scale_safe);

% 5. Generate the VHDL Package
fileID = fopen('svm_params_pkg.vhd', 'w');
fprintf(fileID, 'library ieee;\nuse ieee.std_logic_1164.all;\nuse ieee.numeric_std.all;\n\n');
fprintf(fileID, 'package svm_params_pkg is\n');
fprintf(fileID, '    -- Weights scaled by %f to fit 16-bit signed range\n', W_scale_safe);
fprintf(fileID, '    -- Bias scaled by %f to match (Feature_Q15 * Weight)\n\n', B_scale_safe);

for j = 1:numClasses
    current_name = char(classNames(j));
    fprintf(fileID, '    -- Class %d: %s\n', j-1, current_name);
    for i = 1:numFeatures
        fprintf(fileID, '    constant W_%d_%d : signed(15 downto 0) := to_signed(%d, 16);\n', j-1, i-1, W_fixed(i, j));
    end
    % Bias is 48-bit to handle the massive magnitude of scaled B
    fprintf(fileID, '    constant B_%d   : signed(47 downto 0) := to_signed(%0.0f, 48);\n\n', j-1, B_fixed(j));
end
fprintf(fileID, 'end package svm_params_pkg;');
fclose(fileID);