clc; clear; close all;

 numSamples = 6000;
% Pre-allocate for speed (as discussed!)
dummy_feat = extract_features_v2(randn(1,4096), 100e3);
X = zeros(numSamples, length(dummy_feat));
Y_raw = strings(numSamples, 1);
fprintf('Generating dataset...\n');
for k = 1:numSamples
    [x, label, fs, snr] = gen_amc_dataset_pro();
    X(k, :) = extract_features_v2(x, fs);
    Y_raw(k) = label;
end
Y = categorical(Y_raw);
% ==========================================
% 1. TRAIN/TEST SPLIT (80/20)
% ==========================================
cv = cvpartition(Y, 'Holdout', 0.2);
X_train = X(training(cv), :);
Y_train = Y(training(cv));
X_test = X(test(cv), :);
Y_test = Y(test(cv));

% ==========================================
% 2. NORMALIZATION (Based ONLY on Training)
% ==========================================
mu = mean(X_train, 1);
sigma = std(X_train, 0, 1) + eps;
X_train_n = (X_train - mu) ./ sigma;
X_test_n = (X_test - mu) ./ sigma; % Apply train-mu/sigma to test

% ========================================== 
% 3. TRAIN STABLE LINEAR SVM (REVERTED)
% ========================================== 
fprintf('Training Stable Linear SVM...\n');

% Back to the simple template that produced 87.42%
t = templateLinear('Learner', 'svm', 'Regularization', 'lasso');  

trained_model = fitcecoc(X_train_n, Y_train, ... 
    'Learners', t, ... 
    'Coding', 'onevsall');

% ========================================== 
% 4. EVALUATION & EXPORT
% ========================================== 
Y_pred = predict(trained_model, X_test_n);
fprintf('Accuracy: %.2f%%\n', sum(Y_pred == Y_test)/length(Y_test)*100);
confusionchart(Y_test, Y_pred);

% Extract Weights for FPGA
classes = trained_model.ClassNames;
Weights = zeros(size(X,2), length(classes));
Biases = zeros(1, length(classes));

for i = 1:length(classes)
    binaryModel = trained_model.BinaryLearners{i};
    Weights(:, i) = binaryModel.Beta;
    Biases(i) = binaryModel.Bias;
end

% Save everything for your test script
save('Linear_Best_Model.mat', 'trained_model', 'mu', 'sigma', 'Weights', 'Biases');